%sizechoose=[19,22,40,43,79,82];
%for j =1:size(sizechoose')
    %e1implicit(sizechoose(j));
%    e1implicit(sizechoose(j));
%end
sizechoose=[4];%,9601];
for j =1:size(sizechoose')
    e1explicit(sizechoose(j));
end